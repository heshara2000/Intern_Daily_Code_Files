package lk.gugsi.iit.l7.cp.week03;

public class Main {

	public static void main(String[] args) {
		
		Runnable t1 = new MyThread();
		Thread thread1 = new Thread(t1, "My Thread 01"); // thread1 enters the NEW state
		System.out.println(thread1.getName()+" is current status "+thread1.getState());//NEW state
		Runnable t2 = new MyThread();
		Thread thread2 = new Thread(t2, "My Thread 02");
		Runnable t3 = new MyThread();
		Thread thread3 = new Thread(t3, "My Thread 03");
		thread1.start();
		try {
			thread1.join();// puts the other threads into WAITING state and once it completes the execution other threads can start the execution
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		thread2.start();
		try {
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		thread3.start(); // threat1 enters the RUNNABLE state one of the Thread in the RUNNABLE state will be running depends on number of core
		
		// only other thread that will be in the RUNNABLE state is main thread
		
		try {
			thread3.join(1000);
			// asks main thread to wait for 10000MS or until thread3 is to die down whatever that comes first
			
			// main thread is asked wait because only other thread that is asked to be in the TIMED_WAITING state for 10000ms or My Thread 03 to die down
			// right now that is what happened here where the main thread didnt wait for 10000ms since My Thread 03 completed the execution before timeout 
			// once the thread3 dies down the main thread will starting though more time is therefore it to wait because whatever happens first 
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println(thread1.getName()+" is current status "+thread1.getState());//RUNNABLE state,  TIMED_WAITING state or BLOCKED state 
		System.out.println(thread2.getName()+" is current status "+thread2.getState());//RUNNABLE state or TIMED_WAITING state 
		System.out.println(thread3.getName()+" is current status "+thread3.getState());//RUNNABLE state or TIMED_WAITING state 		
		System.out.println(Thread.currentThread().getName()+" is current status "+Thread.currentThread().getState());
	}

}
