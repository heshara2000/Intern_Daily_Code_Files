package lk.gugsi.iit.l7.cp.week03;

public class MyThread implements Runnable {

	@Override
	public void run() {// body of the thread
		for (int i = 0; i < 25; i++) {
			System.out.println(Thread.currentThread().getName()+" current value of i is "+i);
			try {
				Thread.sleep(i); // Currently running Thread will be put on TIMED_WAITING state 
			} catch (InterruptedException e) {
				System.out.println("ERROR"+e.getMessage());
			}
		}

	}

}
