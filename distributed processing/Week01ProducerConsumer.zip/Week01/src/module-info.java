/**
 * 
 */
/**
 * @author gugsi
 *
 */
module Week01 {
}