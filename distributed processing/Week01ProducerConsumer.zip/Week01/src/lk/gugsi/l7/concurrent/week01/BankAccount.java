package lk.gugsi.l7.concurrent.week01;

public class BankAccount {
	
	private double balance;
	private String accountNo;
	
	public BankAccount(double balance, String accountNo) {
		super();
		this.balance = balance;
		this.accountNo = accountNo;
	}

	public synchronized double getBalance() {
		return balance;
	}

	public String getAccountNo() {
		return accountNo;
	}
	
	public synchronized void withdraw(double amount) {
		
		while (balance < amount) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		
		if (amount > 0 && balance >= amount) {
			this.balance -= amount;
			System.out.println("Withrawal Successful!!!");
			System.out.println(Thread.currentThread().getName()+
					" the balance after withraw is "+
					this.getBalance());
		} else {
			throw new IllegalArgumentException("Insufficient funds or Invalid Amount");
		}
		notifyAll();
	}
	
	public synchronized void deposit(double amount) {
		while (balance >= 10000) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		if (amount > 0) {
			this.balance += amount;
			System.out.println("Desposit Successful!!!");
			System.out.println(Thread.currentThread().getName()+
					" the balance after deposit is "+
					this.getBalance());
		} else {
			throw new IllegalArgumentException("Invalid Amount. Amount cannot be ZERO or lesser");
		}
		notifyAll();
	}
}
