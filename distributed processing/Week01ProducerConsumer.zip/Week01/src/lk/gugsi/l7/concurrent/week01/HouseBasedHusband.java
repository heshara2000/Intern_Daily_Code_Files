package lk.gugsi.l7.concurrent.week01;

public class HouseBasedHusband implements Runnable{
	
	private BankAccount bankAccount;
	
	public HouseBasedHusband(BankAccount bankAccount) {
		super();
		this.bankAccount = bankAccount;
	}

	@Override
	public void run() { // HBH threads body
		for (int i = 1; i <= 10; i++) {
			try {
				bankAccount.withdraw(10000);// if IllegalArgumentException 	
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
		}
	}

}
